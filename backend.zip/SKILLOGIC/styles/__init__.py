"""SKILLOGIC styles package."""
